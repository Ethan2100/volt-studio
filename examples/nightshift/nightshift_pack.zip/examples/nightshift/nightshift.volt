// =====================================================================
//  THE NIGHTSHIFT - a first-person 3D horror game, written in Volt
//
//  You work the night shift in an endless underground facility.
//  Find the 3 energy charges on each floor, get back to the elevator
//  and ride down. The Hunter is always somewhere in the dark.
//
//  W A S D   walk              mouse (click first)   look   (or the arrow keys)
//  SHIFT     sprint (loud!)    E                     hide in a locker / call the elevator
//  M         music on/off      ENTER                 start / try again
//
//  The world is made of 3D models (Kenney, CC0) that were recoloured for this game.
//  Units: 1 = 1 cm in the 3D world. Positions are kept in millimetres (x10).
// =====================================================================
#html
title "The Nightshift"
canvas 320, 180
world3d "#020204" fog 2800 ambient 7 shadows

model3d inter = "models/k_corridor_intersection.glb"
model3d corr = "models/k_corridor.glb"
model3d corn = "models/k_corridor_corner.glb"
model3d endp = "models/k_corridor_end.glb"
model3d jun = "models/k_corridor_junction.glb"
model3d gate = "models/k_gate_door.glb"
model3d hunter = "models/hunter.glb"
model3d tallM = "models/s_container_tall.glb"
model3d crateM = "models/s_container.glb"
model3d compM = "models/s_computer.glb"
model3d pipeM = "models/s_pipe.glb"
model3d pipeBM = "models/s_pipe_bend.glb"
model3d tableM = "models/s_table.glb"
model3d chairM = "models/s_chair.glb"

// ---------- the map: a maze of 4 metre tiles ----------
let MW = 8
let MH = 8
let CS = 4000                // one tile is 4 m (4000 mm)
let opE = []                 // opE[c] = 1 when tile c is open to the east
let opS = []                 // opS[c] = 1 when tile c is open to the south
let seen = []
let stack = []
let nb = []
let dist = []                // distance-to-target for the creature's pathfinding
let queue = []
let startC = 0               // the tile with the elevator
let lockC = []               // lockers: tile and wall direction
let lockD = []
let lockX = []
let lockZ = []
let cellX = []               // energy charges (millimetres)
let cellZ = []
let cellGot = []
let cellId = []
let cellLamp = []

// ---------- game state ----------
let state = 0                // 0 title, 1 playing, 2 caught, 3 riding, 4 escaped
let floor = 1
let best = saved("ns_best", 1)
let t = 0
let cells = 0
let px = 0                   // player position in mm
let pz = 0
let yaw = 0                  // tenths of a degree
let pitch = 0
let stam = 600
let tired = 0
let hidden = 0
let hideIdx = 0
let hideCool = 0
let seenHiding = 0
let stepAcc = 0
let bob = 0
let msg = ""
let msgT = 0
let fadeIn = 90
let rideT = 0
let deadT = 0
let won = 0
let musicOn = 1
let gateOpen = 0
let gateId = 0
let zoneName = ""

// ---------- the Hunter ----------
let hunterId = 0
let hanim = 9
let mx = 0                   // position in mm
let mz = 0
let myaw = 0
let mstate = 0               // 0 patrol, 1 chase, 2 investigate, 3 sniff
let mtimer = 0
let mlost = 0
let mgoalC = 0               // tile the Hunter is heading for
let mpath = 0
let rolled = 0
let hbT = 0
let alertCool = 0
let monLamp = 0
let elevRed = 0
let elevGreen = 0
let elevInd = 0

// ---------- helpers ----------
fn dst(ax, ay, bx, by) {
  let dx = abs(ax - bx)
  let dy = abs(ay - by)
  return max(dx, dy) + min(dx, dy) * 4 / 10
}

fn dirX(d) {
  if d == 0 {
    return 1
  }
  if d == 2 {
    return 0 - 1
  }
  return 0
}

fn dirZ(d) {
  if d == 1 {
    return 1
  }
  if d == 3 {
    return 0 - 1
  }
  return 0
}

// is tile c open in direction d? (0 east, 1 south, 2 west, 3 north)
fn canGo(c, d) {
  let cx = c % MW
  let cy = c / MW
  if d == 0 {
    if cx >= MW - 1 {
      return 0
    }
    return opE[c]
  }
  if d == 1 {
    if cy >= MH - 1 {
      return 0
    }
    return opS[c]
  }
  if d == 2 {
    if cx <= 0 {
      return 0
    }
    return opE[c - 1]
  }
  if cy <= 0 {
    return 0
  }
  return opS[c - MW]
}

fn setEdge(c, d, v) {
  let cx = c % MW
  let cy = c / MW
  if d == 0 and cx < MW - 1 {
    opE[c] = v
  }
  if d == 1 and cy < MH - 1 {
    opS[c] = v
  }
  if d == 2 and cx > 0 {
    opE[c - 1] = v
  }
  if d == 3 and cy > 0 {
    opS[c - MW] = v
  }
}

fn nbr(c, d) {
  if d == 0 {
    return c + 1
  }
  if d == 1 {
    return c + MW
  }
  if d == 2 {
    return c - 1
  }
  return c - MW
}

fn inGrid(c, d) {
  let cx = c % MW
  let cy = c / MW
  if d == 0 and cx >= MW - 1 {
    return 0
  }
  if d == 1 and cy >= MH - 1 {
    return 0
  }
  if d == 2 and cx <= 0 {
    return 0
  }
  if d == 3 and cy <= 0 {
    return 0
  }
  return 1
}

// can a body of radius r stand at (x, z)? (millimetres). Walls are 1.6 m from a tile's middle.
fn blocked(x, z, r) {
  if x < 0 or z < 0 {
    return 1
  }
  let cx = x / CS
  let cz = z / CS
  if cx >= MW or cz >= MH {
    return 1
  }
  let c = cz * MW + cx
  let lx = x - cx * CS - 2000
  let lz = z - cz * CS - 2000
  let lim = 1600 - r
  if lx > lim and canGo(c, 0) == 0 {
    return 1
  }
  if lx < 0 - lim and canGo(c, 2) == 0 {
    return 1
  }
  if lz > lim and canGo(c, 1) == 0 {
    return 1
  }
  if lz < 0 - lim and canGo(c, 3) == 0 {
    return 1
  }
  if abs(lx) > lim and abs(lz) > lim {
    return 1
  }
  return 0
}

// can (x0, z0) see (x1, z1) without a wall in between?
fn los(x0, z0, x1, z1) {
  let d = dst(x0, z0, x1, z1)
  let n = d / 300 + 1
  for i from 1 to n {
    let sx = x0 + (x1 - x0) * i / n
    let sz = z0 + (z1 - z0) * i / n
    if blocked(sx, sz, 1) == 1 {
      return 0
    }
  }
  return 1
}

fn say(text1, frames) {
  msg = text1
  msgT = frames
}

fn zoneOf() {
  return (floor - 1) % 3 + 1
}

// ---------- making a floor ----------
fn makeMap() {
  opE = []
  opS = []
  seen = []
  dist = []
  for i from 1 to MW * MH {
    add 0 to opE
    add 0 to opS
    add 0 to seen
    add 9999 to dist
  }
  // the elevator is on the south edge
  startC = (MH - 1) * MW + random(1, MW - 2)
  stack = []
  seen[startC] = 1
  add startC to stack
  while length(stack) > 0 {
    let top = stack[length(stack) - 1]
    nb = []
    for d from 0 to 3 {
      if inGrid(top, d) == 1 {
        if seen[nbr(top, d)] == 0 {
          add d to nb
        }
      }
    }
    if length(nb) == 0 {
      remove stack[length(stack) - 1]
    } else {
      let pick = nb[random(0, length(nb) - 1)]
      setEdge(top, pick, 1)
      let nx = nbr(top, pick)
      seen[nx] = 1
      add nx to stack
    }
  }
  // a few extra doorways so there are loops to run round
  for k from 1 to 12 {
    let c = random(0, MW * MH - 1)
    let d = random(0, 3)
    if c != startC and inGrid(c, d) == 1 {
      if nbr(c, d) != startC {
        setEdge(c, d, 1)
      }
    }
  }
}

fn bfs(goal) {
  let n = MW * MH
  let i = 0
  while i < n {
    dist[i] = 9999
    i += 1
  }
  queue = []
  dist[goal] = 0
  add goal to queue
  let head = 0
  while head < length(queue) {
    let cur = queue[head]
    head += 1
    let d1 = dist[cur] + 1
    for d from 0 to 3 {
      if canGo(cur, d) == 1 {
        let nx = nbr(cur, d)
        if dist[nx] > d1 {
          dist[nx] = d1
          add nx to queue
        }
      }
    }
  }
}

fn placeThings() {
  px = (startC % MW) * CS + 2000
  pz = (startC / MW) * CS + 2000
  yaw = 0
  for d0 from 0 to 3 {
    if canGo(startC, d0) == 1 {
      yaw = ((d0 + 3) % 4) * 900
    }
  }
  pitch = 0
  bfs(startC)
  // the Hunter starts in the tile farthest from the elevator
  let far = 0
  let fd = 0
  for c from 0 to MW * MH - 1 {
    if dist[c] > fd and dist[c] < 9999 {
      fd = dist[c]
      far = c
    }
  }
  mx = (far % MW) * CS + 2000
  mz = (far / MW) * CS + 2000
  // three charges in different tiles, never near the elevator or the Hunter's own tile
  cellX = []
  cellZ = []
  cellGot = []
  let used = [far, startC]
  let found = 0
  let tries = 0
  while found < 3 and tries < 500 {
    tries += 1
    let c = random(0, MW * MH - 1)
    let ok = 1
    if dist[c] < 4 or dist[c] > 9000 {
      ok = 0
    }
    for u from 0 to length(used) - 1 {
      if used[u] == c {
        ok = 0
      }
    }
    if ok == 1 {
      add c to used
      let ccx = (c % MW) * CS + 2000
      let ccz = (c / MW) * CS + 2000
      add ccx to cellX
      add ccz to cellZ
      add 0 to cellGot
      found += 1
    }
  }
  while found < 3 {
    add mx to cellX
    add mz to cellZ
    add 0 to cellGot
    found += 1
  }
  // lockers, each against a closed wall
  lockC = []
  lockD = []
  lockX = []
  lockZ = []
  tries = 0
  while length(lockC) < 6 and tries < 400 {
    tries += 1
    let c2 = random(0, MW * MH - 1)
    let d2 = random(0, 3)
    if c2 != startC and c2 != far and canGo(c2, d2) == 0 {
      let dup = 0
      for q from 0 to length(lockC) - 1 {
        if lockC[q] == c2 {
          dup = 1
        }
      }
      if dup == 0 {
        add c2 to lockC
        add d2 to lockD
        let lkx2 = (c2 % MW) * CS + 2000 + dirX(d2) * 1250
        let lkz2 = (c2 / MW) * CS + 2000 + dirZ(d2) * 1250
        add lkx2 to lockX
        add lkz2 to lockZ
      }
    }
  }
  myaw = 0
  mstate = 0
  mtimer = 0
  mlost = 0
  pickWaypoint()
}

fn pickWaypoint() {
  mgoalC = random(0, MW * MH - 1)
  bfs(mgoalC)
}

fn cellOf(x, z) {
  return (z / CS) * MW + x / CS
}

// ---------- building the 3D scene ----------
fn placeTile(c) {
  let cx = c % MW
  let cz = c / MW
  let e = canGo(c, 0)
  let s2 = canGo(c, 1)
  let w = canGo(c, 2)
  let n = canGo(c, 3)
  let cnt = e + s2 + w + n
  let x = cx * 400 + 200
  let z = cz * 400 + 200
  let tid = 0
  if cnt >= 4 {
    tid = put3d(inter, x, 0, z, 0, 100)
  } else if cnt == 3 {
    let closed = 0
    if s2 == 0 {
      closed = 1
    }
    if w == 0 {
      closed = 2
    }
    if n == 0 {
      closed = 3
    }
    tid = put3d(jun, x, 0, z, ((closed + 3) % 4) * 900, 100)
  } else if cnt == 2 {
    if e == 1 and w == 1 {
      tid = put3d(corr, x, 0, z, 0, 100)
    } else if s2 == 1 and n == 1 {
      tid = put3d(corr, x, 0, z, 900, 100)
    } else {
      let d = 0
      if s2 == 1 and w == 1 {
        d = 1
      }
      if w == 1 and n == 1 {
        d = 2
      }
      if n == 1 and e == 1 {
        d = 3
      }
      tid = put3d(corn, x, 0, z, ((d + 2) % 4) * 900, 100)
    }
  } else {
    let k = 0
    if s2 == 1 {
      k = 1
    }
    if w == 1 {
      k = 2
    }
    if n == 1 {
      k = 3
    }
    tid = put3d(endp, x, 0, z, k * 900, 100)
  }
}

fn addProp(kind, x, z, yw) {
  let pid = 0
  if kind == 0 {
    pid = put3d(crateM, x, 0, z, yw, 170)
  } else if kind == 1 {
    pid = put3d(compM, x, 0, z, yw, 190)
  } else if kind == 2 {
    pid = put3d(pipeM, x, 130, z, yw, 130)
  } else if kind == 3 {
    pid = put3d(pipeBM, x, 130, z, yw, 130)
  } else if kind == 4 {
    pid = put3d(tableM, x, 0, z, yw, 170)
  } else {
    pid = put3d(chairM, x, 0, z, yw, 170)
  }
}

fn build3d() {
  clear3d
  torch3d 11, 2400
  let zone = zoneOf()
  for c from 0 to MW * MH - 1 {
    placeTile(c)
  }
  let roof = block3d(MW * 200, 440, MH * 200, MW * 400 + 100, 10, MH * 400 + 100, "#141418")
  // props along the walls: crates in the halls, pipes in the boiler room, desks in storage
  for k from 1 to 22 {
    let c = random(0, MW * MH - 1)
    let d = random(0, 3)
    if c != startC and canGo(c, d) == 0 {
      let offs = random(0 - 500, 500)
      let x = (c % MW) * CS + 2000 + dirX(d) * 1250 + dirZ(d) * offs
      let z = (c / MW) * CS + 2000 + dirZ(d) * 1250 + dirX(d) * offs
      let kind = 0
      if zone == 1 {
        kind = random(0, 1)
      } else if zone == 2 {
        kind = random(2, 3)
      } else {
        kind = random(4, 5)
      }
      addProp(kind, x / 10, z / 10, ((d + 1) % 4) * 900)
    }
  }
  // lights
  let lc = "#ffd9a8"
  if zone == 2 {
    lc = "#ff6a2a"
  }
  if zone == 3 {
    lc = "#9a7bff"
  }
  for k2 from 1 to 9 {
    let c3 = random(0, MW * MH - 1)
    let l1 = lamp3d((c3 % MW) * 400 + 200, 330, (c3 / MW) * 400 + 200, lc, 15, 800)
  }
  // lockers
  let i = 0
  while i < length(lockC) {
    let lk = put3d(tallM, lockX[i] / 10, 0, lockZ[i] / 10, ((lockD[i] + 1) % 4) * 900, 190)
    i += 1
  }
  // the elevator: a gate set into the south wall of the first tile
  let gx = (startC % MW) * 400 + 200
  let gz = (startC / MW) * 400 + 200 + 190
  gateId = put3d(gate, gx, 0, gz, 0, 100)
  anim3d gateId, "close"
  gateOpen = 0
  elevInd = block3d(gx, 330, gz - 60, 50, 10, 4, "#300000")
  glow3d elevInd, "#ff2a1a"
  elevRed = lamp3d(gx, 260, gz - 120, "#ff3322", 14, 520)
  elevGreen = lamp3d(gx, 260, gz - 120, "#33ff77", 14, 520)
  show3d elevGreen, 0
  // energy charges
  cellId = []
  cellLamp = []
  for c2 from 0 to 2 {
    let cb = block3d(cellX[c2] / 10, 110, cellZ[c2] / 10, 22, 34, 22, "#2a8aa8")
    glow3d cb, "#4de1ff"
    add cb to cellId
    add lamp3d(cellX[c2] / 10, 120, cellZ[c2] / 10, "#4de1ff", 18, 450) to cellLamp
  }
  // the Hunter
  hunterId = put3d(hunter, mx / 10, 0, mz / 10, 0, 100)
  hanim = 9
  setAnim(0)
  monLamp = lamp3d(0, 150, 0, "#ff2211", 10, 340)
  placeMonster()
}

fn setAnim(a) {
  if a == hanim {
    return 0
  }
  hanim = a
  if a == 0 {
    anim3d hunterId, "walk"
  } else if a == 1 {
    anim3d hunterId, "sprint"
  } else {
    anim3d hunterId, "idle"
  }
}

fn placeMonster() {
  move3d hunterId, mx / 10, 0, mz / 10
  turn3d hunterId, myaw + 1800
  move3d monLamp, mx / 10, 150, mz / 10
}

fn newFloor() {
  makeMap()
  placeThings()
  build3d()
  cells = 0
  hidden = 0
  stam = 600
  tired = 0
  msg = ""
  msgT = 0
  fadeIn = 90
  mpath = 0
  bestCheck()
  let z = zoneOf()
  if z == 1 {
    zoneName = "CONCRETE HALLS"
  } else if z == 2 {
    zoneName = "BOILER ROOM"
  } else {
    zoneName = "DEEP STORAGE"
  }
  if floor == 1 {
    say("FIND 3 ENERGY CHARGES", 240)
  } else {
    say("FLOOR " + floor + " - " + zoneName, 180)
  }
}

fn bestCheck() {
  if floor > best {
    best = floor
    save "ns_best", best
  }
}

// ---------- pathfinding for the Hunter ----------
// the neighbouring tile that is closest to the goal
fn nextCell() {
  let c = cellOf(mx, mz)
  let bestN = c
  let bd = dist[c]
  for d from 0 to 3 {
    if canGo(c, d) == 1 {
      let nx = nbr(c, d)
      if dist[nx] < bd {
        bd = dist[nx]
        bestN = nx
      }
    }
  }
  return bestN
}

// move towards a point, sliding along walls
fn moveMon(gx, gz, spd) {
  let d = dst(mx, mz, gx, gz)
  if d < 1 {
    return 0
  }
  let nx = mx
  let nz = mz
  if d <= spd {
    nx = gx
    nz = gz
  } else {
    nx = mx + (gx - mx) * spd / d
    nz = mz + (gz - mz) * spd / d
  }
  if blocked(nx, nz, 450) == 0 {
    mx = nx
    mz = nz
  } else if blocked(nx, mz, 450) == 0 {
    mx = nx
  } else if blocked(mx, nz, 450) == 0 {
    mz = nz
  }
  myaw = atan2(gx - mx, mz - gz)
  return 1
}

fn followPath(spd) {
  let nc = nextCell()
  moveMon((nc % MW) * CS + 2000, (nc / MW) * CS + 2000, spd)
}

// ---------- the Hunter's brain ----------
fn monsterFrame() {
  let spdPatrol = 16 + floor * 3
  let spdChase = 24 + floor * 6
  let sight = 11000 + floor * 500
  let d = dst(px, pz, mx, mz)
  let sees = 0
  if hidden == 0 and d < sight {
    sees = los(mx, mz, px, pz)
  }
  if alertCool > 0 {
    alertCool -= 1
  }
  if mstate == 0 or mstate == 2 or mstate == 3 {
    if sees == 1 {
      mstate = 1
      mlost = 0
      mgoalC = cellOf(px, pz)
      bfs(mgoalC)
      mpath = 0
      tone 180 to 60 for 350ms
      say("IT SEES YOU - RUN", 120)
    } else if hidden == 0 and mstate != 1 {
      let heard = 0
      if stepAcc > 0 and held("shift") and tired == 0 and d < 9000 {
        heard = 1
      }
      if d < 3000 {
        heard = 1
      }
      if heard == 1 and alertCool == 0 and mstate != 2 {
        mstate = 2
        mgoalC = cellOf(px, pz)
        bfs(mgoalC)
        alertCool = 240
      }
    }
  }
  let gcx = (mgoalC % MW) * CS + 2000
  let gcz = (mgoalC / MW) * CS + 2000
  if mstate == 0 {
    setAnim(0)
    followPath(spdPatrol)
    if dst(mx, mz, gcx, gcz) < 600 {
      mstate = 3
      mtimer = 120
      rolled = 1
    }
  } else if mstate == 1 {
    setAnim(1)
    if sees == 1 {
      mlost = 0
      mgoalC = cellOf(px, pz)
    } else {
      mlost += 1
    }
    mpath += 1
    if mpath >= 8 {
      mpath = 0
      bfs(mgoalC)
    }
    if sees == 1 and d < 5000 {
      moveMon(px, pz, spdChase)
    } else {
      followPath(spdChase)
    }
    if sees == 0 and dst(mx, mz, gcx, gcz) < 700 {
      mstate = 3
      mtimer = 150
      rolled = 0
    }
    if sees == 0 and mlost > 420 {
      mstate = 0
      pickWaypoint()
    }
  } else if mstate == 2 {
    setAnim(0)
    followPath((spdPatrol + spdChase) / 2)
    if dst(mx, mz, gcx, gcz) < 700 {
      mstate = 3
      mtimer = 110
      rolled = 0
    }
  } else if mstate == 3 {
    setAnim(2)
    mtimer -= 1
    myaw += 14
    if myaw >= 3600 {
      myaw -= 3600
    }
    if mtimer == 60 and rolled == 0 {
      rolled = 1
      if hidden == 1 {
        if dst(mx, mz, lockX[hideIdx], lockZ[hideIdx]) < 4200 {
          let chance = 30 + floor * 10 + seenHiding * 45
          if chance > 95 {
            chance = 95
          }
          if random(1, 100) <= chance {
            caught()
          }
        }
      }
    }
    if mtimer <= 0 {
      mstate = 0
      pickWaypoint()
    }
  }
  if state == 1 and hidden == 0 and dst(px, pz, mx, mz) < 900 {
    caught()
  }
}

fn caught() {
  if state != 1 {
    return 0
  }
  state = 2
  deadT = 0
  hidden = 0
  torch3d 0, 2400
  tone 900 to 90 for 600ms
  music off
}

// ---------- the player ----------
fn playerFrame() {
  if hideCool > 0 {
    hideCool -= 1
  }
  if hidden == 1 {
    stam = min(600, stam + 2)
    return 0
  }
  yaw += mousedx() * 3
  pitch -= mousedy() * 3
  pitch = constrain(pitch, 0 - 800, 800)
  if held("left") {
    yaw -= 28
  }
  if held("right") {
    yaw += 28
  }
  if yaw >= 3600 {
    yaw -= 3600
  }
  if yaw < 0 {
    yaw += 3600
  }
  let fwd = 0
  let side = 0
  if held("w") or held("up") {
    fwd += 1
  }
  if held("s") or held("down") {
    fwd -= 1
  }
  if held("d") {
    side += 1
  }
  if held("a") {
    side -= 1
  }
  let moving = 0
  if fwd != 0 or side != 0 {
    moving = 1
  }
  let spd = 26
  if moving == 1 and held("shift") and stam > 0 and tired == 0 {
    spd = 44
    stam -= 2
    if stam <= 0 {
      stam = 0
      tired = 1
      say("OUT OF BREATH", 90)
    }
  } else {
    if moving == 1 {
      stam = min(600, stam + 1)
    } else {
      stam = min(600, stam + 3)
    }
    if tired == 1 and stam >= 240 {
      tired = 0
    }
  }
  let dx = (sin(yaw) * fwd + cos(yaw) * side) * spd / 1000
  let dz = (0 - cos(yaw) * fwd + sin(yaw) * side) * spd / 1000
  if fwd != 0 and side != 0 {
    dx = dx * 7 / 10
    dz = dz * 7 / 10
  }
  if blocked(px + dx, pz, 420) == 0 {
    px += dx
  }
  if blocked(px, pz + dz, 420) == 0 {
    pz += dz
  }
  if moving == 1 {
    stepAcc += spd
    bob += spd
    if stepAcc > 900 {
      stepAcc = 1
      tone 70 for 35ms
    }
  } else {
    stepAcc = 0
  }
  for c from 0 to 2 {
    if cellGot[c] == 0 and dst(px, pz, cellX[c], cellZ[c]) < 1000 {
      cellGot[c] = 1
      cells += 1
      show3d cellId[c], 0
      show3d cellLamp[c], 0
      tone 660 for 70ms
      if cells == 3 {
        tone 880 for 160ms
        say("ELEVATOR POWERED - GET BACK", 240)
        show3d elevRed, 0
        show3d elevGreen, 1
        glow3d elevInd, "#22ff66"
        mstate = 2
        mgoalC = cellOf(px, pz)
        bfs(mgoalC)
        alertCool = 600
      } else {
        say("ENERGY CHARGE " + cells + " / 3", 120)
      }
    }
  }
}

// something is close: the flashlight misbehaves
fn torchFrame() {
  if hidden == 1 {
    torch3d 10, 2400
    return 0
  }
  let d = dst(px, pz, mx, mz)
  let pw = 11
  if d < 6500 and random(1, 100) <= 18 {
    pw = random(2, 8)
  }
  torch3d pw, 2400
}

fn heartbeat() {
  let d = dst(px, pz, mx, mz)
  if d < 14000 {
    hbT += 1
    if hbT >= 22 + d / 240 {
      hbT = 0
      tone 60 to 38 for 120ms
    }
  }
}

// where you stand to use the elevator
fn elevX() {
  return (startC % MW) * CS + 2000
}

fn elevZ() {
  return (startC / MW) * CS + 2000 + 1600
}

// ---------- E: hide, leave a locker, call the elevator ----------
when key "e" pressed {
  interact()
}

fn interact() {
  if state != 1 {
    return 0
  }
  if hidden == 1 {
    hidden = 0
    hideCool = 30
    px = (lockC[hideIdx] % MW) * CS + 2000
    pz = (lockC[hideIdx] / MW) * CS + 2000
    return 0
  }
  if hideCool > 0 {
    return 0
  }
  let i = 0
  while i < length(lockC) {
    if dst(px, pz, lockX[i], lockZ[i]) < 2200 {
      hidden = 1
      hideIdx = i
      hideCool = 30
      seenHiding = 0
      if mstate == 1 and los(mx, mz, px, pz) == 1 and dst(mx, mz, px, pz) < 9000 {
        seenHiding = 1
      }
      yaw = ((lockD[i] + 3) % 4) * 900
      pitch = 0
      tone 120 for 60ms
      return 0
    }
    i += 1
  }
  if dst(px, pz, elevX(), elevZ()) < 2400 {
    if cells < 3 {
      say("NO POWER - " + cells + " / 3 CHARGES", 150)
      tone 140 for 120ms
    } else {
      if floor >= 3 and won == 0 {
        state = 4
        won = 1
        bestCheck()
        music off
        tone 523 for 120ms
      } else {
        state = 3
        rideT = 0
        tone 440 for 120ms
      }
    }
  }
}

fn startMusic() {
  if musicOn == 1 {
    music "e3 - - - - - - - - - - - d#3 - - -", "a1 - - - - - - - - - - - - - - -" tempo 46
  }
}

when key "enter" pressed {
  if state == 0 or state == 2 {
    floor = 1
    won = 0
    state = 1
    newFloor()
    startMusic()
  } else if state == 4 {
    floor += 1
    state = 1
    newFloor()
    startMusic()
  }
}

when key "m" pressed {
  if musicOn == 1 {
    musicOn = 0
    music off
  } else {
    musicOn = 1
    if state == 1 {
      startMusic()
    }
  }
}

// ---------- the 2D layer (HUD) on top of the 3D world ----------
fn hud() {
  if state == 1 {
    box 159, 89, 2, 2 color "#ffffff70"
    box 6, 5, 96, 40 color "#0b0c10c0"
    write "FLOOR " + floor at 12, 9 color "#d7dbe3"
    write zoneName at 12, 19 color "#8c93a3"
    for c from 0 to 2 {
      let col = "#1a2a30"
      if cellGot[c] == 1 {
        col = "#4de1ff"
      }
      box 12 + c * 14, 30, 11, 11 color "#000000a0"
      box 13 + c * 14, 31, 9, 9 color col
    }
    box 8, 168, 62, 6 color "#000000a0"
    let sc = "#e8e2c8"
    if tired == 1 {
      sc = "#d8503c"
    }
    box 9, 169, stam * 60 / 600, 4 color sc
    let near = 0
    let i = 0
    while i < length(lockC) {
      if hidden == 0 and dst(px, pz, lockX[i], lockZ[i]) < 2200 {
        near = 1
      }
      i += 1
    }
    if near == 1 {
      write "[E] HIDE" at 160, 130 centered shadow
    }
    if hidden == 0 and dst(px, pz, elevX(), elevZ()) < 2400 {
      if cells == 3 {
        write "[E] CALL ELEVATOR" at 160, 130 color "#7dff9c" centered shadow
      } else {
        write "[E] ELEVATOR (" + cells + "/3)" at 160, 130 color "#ff8a7a" centered shadow
      }
    }
    if msgT > 0 {
      write msg at 160, 40 color "#f2e9c9" centered shadow
    }
    if mstate == 1 {
      box 0, 0, 320, 3 color "#ff1a1a60"
      box 0, 177, 320, 3 color "#ff1a1a60"
      box 0, 0, 3, 180 color "#ff1a1a60"
      box 317, 0, 3, 180 color "#ff1a1a60"
    }
    if locked3d() == 0 {
      write "CLICK TO LOOK AROUND" at 160, 160 color "#8c93a3" centered shadow
    }
    if hidden == 1 {
      box 0, 0, 320, 64 color "#050605"
      box 0, 116, 320, 64 color "#050605"
      for s from 0 to 5 {
        box 0, 70 + s * 8, 320, 3 color "#050605"
      }
      box 0, 64, 6, 52 color "#050605"
      box 314, 64, 6, 52 color "#050605"
      write "[E] LEAVE LOCKER" at 160, 164 color "#8c93a3" centered shadow
    }
    if fadeIn > 0 {
      box 0, 0, 320, 180 color "#000000" + hex2(fadeIn * 255 / 90)
    }
  } else if state == 0 {
    box 0, 0, 320, 180 color "#000000b0"
    write "THE NIGHTSHIFT" at 160, 46 color "#e8e2c8" size 3 centered shadow
    write "THE FACILITY NEVER SLEEPS. NEITHER DOES THE HUNTER." at 160, 82 color "#9aa1b0" centered
    write "WASD WALK   SHIFT SPRINT   E HIDE / ELEVATOR" at 160, 112 color "#c9ccd6" centered
    write "MOUSE LOOK (CLICK THE GAME FIRST)" at 160, 123 color "#c9ccd6" centered
    write "FIND 3 ENERGY CHARGES, THEN RIDE THE ELEVATOR DOWN" at 160, 134 color "#c9ccd6" centered
    if (t / 30) % 2 == 0 {
      write "PRESS ENTER" at 160, 150 color "#ffd23f" size 2 centered shadow
    }
    write "DEEPEST FLOOR: " + best at 160, 170 color "#6f7686" centered
  } else if state == 2 {
    let a = min(255, deadT * 4)
    box 0, 0, 320, 180 color "#5a0000" + hex2(min(a, 200))
    if deadT > 40 {
      write "THE HUNTER GOT YOU" at 160, 62 color "#ff3b30" size 3 centered shadow
      write "YOU REACHED FLOOR " + floor at 160, 100 color "#e8e2c8" centered shadow
      write "DEEPEST: " + best at 160, 112 color "#9aa1b0" centered
      if (t / 30) % 2 == 0 {
        write "ENTER: START A NEW SHIFT" at 160, 140 color "#ffd23f" centered shadow
      }
    }
  } else if state == 3 {
    let a = min(255, rideT * 6)
    box 0, 0, 320, 180 color "#000000" + hex2(a)
    if rideT > 40 {
      write "DESCENDING" at 160, 72 color "#9aa1b0" size 2 centered shadow
      write "FLOOR " + (floor + 1) at 160, 98 color "#e8e2c8" size 2 centered shadow
    }
  } else if state == 4 {
    box 0, 0, 320, 180 color "#000000d8"
    write "SHIFT OVER" at 160, 48 color "#7dff9c" size 3 centered shadow
    write "THREE FLOORS DOWN... AND THE ELEVATOR KEEPS GOING." at 160, 88 color "#c9ccd6" centered
    if (t / 30) % 2 == 0 {
      write "ENTER: ONE MORE FLOOR?" at 160, 128 color "#ffd23f" size 2 centered shadow
    }
  }
}

// two hex digits for a number 0..255 (used for see-through black fades)
fn hex2(n) {
  let v = constrain(n, 0, 255)
  let digits = "0123456789abcdef"
  return part(digits, v / 16, 1) + part(digits, v % 16, 1)
}

// ---------- start up: a slowly turning view of the first tile ----------
makeMap()
placeThings()
build3d()
show3d monLamp, 0
let idle = 0

every frame {
  t += 1
  if msgT > 0 {
    msgT -= 1
  }
  if state == 0 {
    idle += 3
    camera3d px / 10, 150, pz / 10, idle, 0 - 40
    torch3d 11, 2400
    show3d monLamp, 0
  } else if state == 1 {
    if fadeIn > 0 {
      fadeIn -= 1
    }
    playerFrame()
    monsterFrame()
    placeMonster()
    torchFrame()
    heartbeat()
    for c from 0 to 2 {
      if cellGot[c] == 0 {
        turn3d cellId[c], t * 12
        move3d cellId[c], cellX[c] / 10, 110 + sin(t * 30) * 8 / 1000, cellZ[c] / 10
      }
    }
    // the elevator doors open when it is powered and you are close
    let want = 0
    if cells == 3 and dst(px, pz, elevX(), elevZ()) < 4000 {
      want = 1
    }
    if want != gateOpen {
      gateOpen = want
      if want == 1 {
        anim3d gateId, "open"
      } else {
        anim3d gateId, "close"
      }
    }
    if hidden == 1 {
      camera3d lockX[hideIdx] / 10, 150, lockZ[hideIdx] / 10, yaw, 0
    } else {
      let bobY = sin(bob * 7) * 4 / 1000
      camera3d px / 10, 165 + bobY, pz / 10, yaw, pitch
    }
  } else if state == 2 {
    deadT += 1
    let want2 = atan2(mx - px, pz - mz)
    let diff = want2 - yaw
    if diff > 1800 {
      diff -= 3600
    }
    if diff < 0 - 1800 {
      diff += 3600
    }
    yaw += diff / 4
    if deadT < 20 {
      moveMon(px, pz, 40)
    }
    placeMonster()
    camera3d px / 10, 165, pz / 10, yaw, 0
  } else if state == 3 {
    rideT += 1
    if rideT == 70 {
      tone 330 for 200ms
    }
    if rideT >= 160 {
      floor += 1
      state = 1
      newFloor()
      startMusic()
    }
    camera3d px / 10, 165 + random(0 - 2, 2), pz / 10, yaw, 0
  } else if state == 4 {
    camera3d px / 10, 165, pz / 10, yaw, 0
  }
  render3d
  hud()
}
